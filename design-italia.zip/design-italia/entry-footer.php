<footer class="entry-footer">
	<h6><span>&#9679;</span> <?php the_category( ', ' ); ?></h6>
	<!-- <span class="tag-links"><?php the_tags(); ?></span>
	<?php if ( comments_open() ) { 
		echo '<span class="meta-sep">|</span> <span class="comments-link"><a href="' . get_comments_link() . '">' . sprintf( __( 'Comments', 'wppa' ) ) . '</a></span>';
	} ?> -->
</footer> 