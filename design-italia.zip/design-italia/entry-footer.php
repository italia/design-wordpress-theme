<footer class="entry-footer">
	<h6><span>&#9679;</span> <?php the_category( ', ' ); ?></h6>
</footer> 