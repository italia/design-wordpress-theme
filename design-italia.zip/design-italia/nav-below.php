<?php 
	wppa_pagination();
?>